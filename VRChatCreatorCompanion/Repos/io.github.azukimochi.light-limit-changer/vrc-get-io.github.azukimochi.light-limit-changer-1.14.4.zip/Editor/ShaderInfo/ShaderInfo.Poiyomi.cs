﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using nadena.dev.ndmf;
using UnityEngine;
using UnityEditor;

namespace io.github.azukimochi
{
    partial class ShaderInfo
    {
        public sealed class Poiyomi : ShaderInfo
        {
            public static Poiyomi Instance { get; } = new Poiyomi();

            public const string _LightingMinLightBrightness = "_LightingMinLightBrightness";
            public const string _LightingCap = "_LightingCap";
            public const string _LightingAdditiveLimit = "_LightingAdditiveLimit";
            public const string _MainColorAdjustToggle = "_MainColorAdjustToggle";
            public const string _Saturation = "_Saturation";
            public const string _MonochromeLighting = "_LightingMonochromatic";
            public const string _MonoChromeAdditiveLighting = "_LightingAdditiveMonochromatic";
            public const string _Color = "_Color";
            public const string _MainTex = "_MainTex";

            public const string _EnableDissolve = "_EnableDissolve";
            public const string _DissolveTextureColor = "_DissolveTextureColor";
            public const string _DissolveToTexture = "_DissolveToTexture";
            
            private bool isDetectOldVersion = false;

            private static class PropertyIDs
            {
                public static readonly int LightingMinLightBrightness = Shader.PropertyToID(_LightingMinLightBrightness);
                public static readonly int LightingCap = Shader.PropertyToID(_LightingCap);
                public static readonly int LightingAdditiveLimit = Shader.PropertyToID(_LightingAdditiveLimit);
                public static readonly int MainColorAdjustToggle = Shader.PropertyToID(_MainColorAdjustToggle);
                public static readonly int Saturation = Shader.PropertyToID(_Saturation);
                public static readonly int Color = Shader.PropertyToID(_Color);
                public static readonly int MainTex = Shader.PropertyToID(_MainTex);
                public static readonly int EnableDissolve = Shader.PropertyToID(_EnableDissolve);
                public static readonly int DissolveTextureColor = Shader.PropertyToID(_DissolveTextureColor);
                public static readonly int DissolveToTexture = Shader.PropertyToID(_DissolveToTexture);
                public static readonly int MainColorAdjustTexture = Shader.PropertyToID("_MainColorAdjustTexture");
                public static readonly int MonochromeLighting = Shader.PropertyToID(_MonochromeLighting);
                public static readonly int MonoChromeAdditiveLighting = Shader.PropertyToID(_MonoChromeAdditiveLighting);
            }

            private static class DefaultParameters
            {
                public static readonly float LightingMinLightBrightness = 0;
                public static readonly float LightingCap = 1;
                public static readonly float Saturation = 0;
                public static readonly Color Color = Color.white;
                public static readonly float MonochromeLighting = 0;
                public static readonly float MonoChromeAdditiveLighting = 0;
            }

            private const string Animated_Suffix = "Animated";
            private const string Flag_IsAnimated = "1";
            private static readonly Material[] singleMaterialArray = new Material[1];

            public override bool TryNormalizeMaterial(Material material, LightLimitChangerObjectCache cache)
            {
                var textureBaker = TextureBaker.GetInstance<PoiyomiTextureBaker>(cache);
                bool result = false;

#if POIYOMI
                singleMaterialArray[0] = material;
                if (!ShaderOptimizer.SetLockedForAllMaterials(singleMaterialArray, 0))
                    return false;
#endif

                {
                    bool bakeFlag = false;
                    var tex = material.GetOrDefault<Texture>(PropertyIDs.MainTex);
                    if (!(tex is RenderTexture))
                    {
                        if (tex != null)
                            textureBaker.Texture = tex;

                        var color = material.GetOrDefault(PropertyIDs.Color, DefaultParameters.Color);
                        if (color != DefaultParameters.Color)
                        {
                            textureBaker.Color = color;
                            material.TrySet(PropertyIDs.Color, DefaultParameters.Color);
                            bakeFlag = true;
                        }

                        var saturation = material.GetOrDefault(PropertyIDs.Saturation, DefaultParameters.Saturation);
                        if (saturation != DefaultParameters.Saturation)
                        {
                            textureBaker.Saturation = saturation;
                            material.TrySet(PropertyIDs.Saturation, DefaultParameters.Saturation);
                            bakeFlag = true;
                        }

                        // 焼き込むべきかどうかいまいちわかんなかったので保留
                        /*var adjustTexture = material.GetOrDefault<Texture>(PropertyIDs.MainColorAdjustTexture, null);
                        if (adjustTexture != null)
                        {
                            textureBaker.ColorAdjustTexture = adjustTexture;
                            material.TrySet<Texture>(PropertyIDs.MainColorAdjustTexture, null);
                            bakeFlag = true;
                        }*/

                        if (bakeFlag)
                        {
                            var baked = cache.Register(textureBaker.Bake());
                            material.TrySet(PropertyIDs.MainTex, baked);
                        }

                        result |= bakeFlag;
                    }
                }

                if (material.GetOrDefault(PropertyIDs.EnableDissolve, 0f) != 0)
                {
                    textureBaker.Reset();

                    bool bakeFlag = false;
                    var tex = material.GetOrDefault<Texture>(PropertyIDs.DissolveToTexture);
                    if (!(tex is RenderTexture))
                    {
                        if (tex != null)
                            textureBaker.Texture = tex;

                        var color = material.GetOrDefault(PropertyIDs.DissolveTextureColor, DefaultParameters.Color);
                        if (color != DefaultParameters.Color)
                        {
                            textureBaker.Color = color;
                            material.TrySet(PropertyIDs.DissolveTextureColor, DefaultParameters.Color);
                            bakeFlag = true;
                        }

                        if (bakeFlag)
                        {
                            var baked = cache.Register(textureBaker.Bake());
                            material.TrySet(PropertyIDs.DissolveToTexture, baked);
                        }

                        result |= bakeFlag;
                    }
                }


                return result;
            }

            public override bool IsTargetShader(Shader shader)
            {
                if (shader.name.Contains("7.3", StringComparison.OrdinalIgnoreCase) && !isDetectOldVersion)
                {
                    IError error = new ErrorMessage("NDMF.info.poiyomi_old_version", ErrorSeverity.NonFatal);
                    ErrorReport.ReportError(error);
                    isDetectOldVersion = true;
                }
                //return shader.name.Contains("poiyomi", StringComparison.OrdinalIgnoreCase);
                return shader.name.Contains(".poiyomi", StringComparison.OrdinalIgnoreCase) &&
                       ! shader.name.Contains("7.3", StringComparison.OrdinalIgnoreCase);
            }

            public override void SetControlAnimation(in ControlAnimationContainer container, in ControlAnimationParameters parameters)
            {
                if (container.ControlType.HasFlag(LightLimitControlType.LightMin))
                {
                    container.Default.SetParameterAnimation(parameters, _LightingMinLightBrightness, parameters.DefaultMinLightValue);
                    container.Control.SetParameterAnimation(parameters, _LightingMinLightBrightness, parameters.MinLightValue, parameters.MaxLightValue);
                }

                if (container.ControlType.HasFlag(LightLimitControlType.LightMax))
                {
                    container.Default.SetParameterAnimation(parameters, _LightingCap, parameters.DefaultMaxLightValue);
                    container.Default.SetParameterAnimation(parameters, _LightingAdditiveLimit, parameters.DefaultMaxLightValue);
                    container.Control.SetParameterAnimation(parameters, _LightingCap, parameters.MinLightValue, parameters.MaxLightValue);
                    container.Control.SetParameterAnimation(parameters, _LightingAdditiveLimit, parameters.MinLightValue, parameters.MaxLightValue);
                }

                if (container.ControlType.HasFlag(LightLimitControlType.Saturation))
                {
                    container.Default.SetParameterAnimation(parameters, _Saturation, DefaultParameters.Saturation);
                    container.Control.SetParameterAnimation(parameters, _Saturation, -1, 1);
                }

                if (container.ControlType.HasFlag(LightLimitControlType.ColorTemperature))
                {
                    container.Default.SetParameterAnimation(parameters, _Color, DefaultParameters.Color);
                    container.Control.SetColorTempertureAnimation(parameters, _Color, DefaultParameters.Color);

                    container.Default.SetParameterAnimation(parameters, _DissolveTextureColor, DefaultParameters.Color);
                    container.Control.SetColorTempertureAnimation(parameters, _DissolveTextureColor, DefaultParameters.Color);
                }
                if (container.ControlType.HasFlag(LightLimitControlType.Monochrome))
                {
                    container.Default.SetParameterAnimation(parameters, _MonochromeLighting, parameters.DefaultMonochromeLightingValue);
                    container.Control.SetParameterAnimation(parameters, _MonochromeLighting, 0, 1);
                    container.Default.SetParameterAnimation(parameters, _MonoChromeAdditiveLighting, parameters.DefaultMonochromeAdditiveLightingValue);
                    container.Control.SetParameterAnimation(parameters, _MonoChromeAdditiveLighting, 0, 1);
                }
            }

            public override void AdditionalControl(Material material, in LightLimitChangerParameters parameters)
            {
                material.SetOverrideTag($"{_LightingCap}{Animated_Suffix}", Flag_IsAnimated);
                material.SetOverrideTag($"{_LightingAdditiveLimit}{Animated_Suffix}", Flag_IsAnimated);
                material.SetOverrideTag($"{_LightingMinLightBrightness}{Animated_Suffix}", Flag_IsAnimated);
                if (parameters.AllowSaturationControl || parameters.AllowColorTempControl)
                {
                    material.TrySet(PropertyIDs.MainColorAdjustToggle, 1f);
                    material.EnableKeyword($"{_MainColorAdjustToggle.ToUpperInvariant()}_ON");
                    material.EnableKeyword("COLOR_GRADING_HDR");

                    if (parameters.AllowColorTempControl)
                    {
                        material.SetOverrideTag($"{_Color}{Animated_Suffix}", Flag_IsAnimated);

                        if (material.GetOrDefault(PropertyIDs.EnableDissolve, 0f) != 0)
                            material.SetOverrideTag($"{_DissolveTextureColor}{Animated_Suffix}", Flag_IsAnimated);
                    }
                    if (parameters.AllowSaturationControl)
                    {
                        material.SetOverrideTag($"{_Saturation}{Animated_Suffix}", Flag_IsAnimated);
                    }
                }

                if (parameters.AllowMonochromeControl)
                {
                    material.SetOverrideTag($"{_MonochromeLighting}{Animated_Suffix}", Flag_IsAnimated);
                    material.SetOverrideTag($"{_MonoChromeAdditiveLighting}{Animated_Suffix}", Flag_IsAnimated);
                }
            }

            public override bool TryGetLightMinMaxValue(Material material, out float min, out float max)
            {
                min = material.GetOrDefault(PropertyIDs.LightingMinLightBrightness, DefaultParameters.LightingMinLightBrightness);
                max = material.GetOrDefault(PropertyIDs.LightingCap, DefaultParameters.LightingCap);
                return true;
            }

            public override bool TryGetMonochromeValue(Material material, out float monochrome, out float monochromeAdditive)
            {
                monochrome = material.GetOrDefault(PropertyIDs.MonochromeLighting, DefaultParameters.MonochromeLighting);
                monochromeAdditive = material.GetOrDefault(PropertyIDs.MonoChromeAdditiveLighting, DefaultParameters.MonoChromeAdditiveLighting);
                return true;
            }
            internal static class ShaderOptimizer
            {
                static ShaderOptimizer()
                {
                    var proxyMethod = typeof(ShaderOptimizer).GetMethod(nameof(SetLockedForAllMaterials));
                    var methodParameters = proxyMethod.GetParameters().Select(x => x.ParameterType).ToArray();

                    foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
                    {
                        if (!assembly.FullName.Contains("Thry", StringComparison.OrdinalIgnoreCase) && !assembly.FullName.Contains("Poiyomi", StringComparison.OrdinalIgnoreCase))
                            continue;

                        foreach (var type in assembly.GetTypes())
                        {
                            if (!type.Name.Contains("ShaderOptimizer"))
                                continue;

                            var targetMethod = type.GetMethod(proxyMethod.Name, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static, null, methodParameters, null);

                            if (targetMethod == null)
                                continue;

                            var method = new DynamicMethod($"{proxyMethod.Name}_Proxy", proxyMethod.ReturnType, methodParameters, true);
                            var il = method.GetILGenerator();
                            for (int i = 0; i < methodParameters.Length; i++)
                            {
                                if (i < 4)
                                {
                                    il.Emit(i switch
                                    {
                                        0 => OpCodes.Ldarg_0,
                                        1 => OpCodes.Ldarg_1,
                                        2 => OpCodes.Ldarg_2,
                                        _ => OpCodes.Ldarg_3,
                                    });
                                }
                                else
                                {
                                    il.Emit(i < byte.MaxValue ? OpCodes.Ldarg_S : OpCodes.Ldarg, i);
                                }
                            }
                            il.Emit(OpCodes.Call, targetMethod);
                            il.Emit(OpCodes.Ret);

                            SetLockedForAllMaterialsProxy = method.CreateDelegate(typeof(SetLockedForAllMaterialsDelegate)) as SetLockedForAllMaterialsDelegate;

                            return;
                        }
                    }
                }

                private delegate bool SetLockedForAllMaterialsDelegate(IEnumerable<Material> materials, int lockState, bool showProgressbar = false, bool showDialog = false, bool allowCancel = true, MaterialProperty shaderOptimizer = null);

                private static readonly SetLockedForAllMaterialsDelegate SetLockedForAllMaterialsProxy;

                public static bool SetLockedForAllMaterials(IEnumerable<Material> materials, int lockState, bool showProgressbar = false, bool showDialog = false, bool allowCancel = true, MaterialProperty shaderOptimizer = null)
                {
                    return SetLockedForAllMaterialsProxy?.Invoke(materials, lockState, showProgressbar, showDialog, allowCancel, shaderOptimizer) ?? false;
                }
            }
        }
    }
}
