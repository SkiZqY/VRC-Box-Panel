MIT License

Copyright (c) 2025 bd_

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.



This product bundles the following components under the described licenses:

--------------------------------------------------------------------------------

Google.Protobuf

Id:        Google.Protobuf
Version:   3.30.1
Project:   https://github.com/protocolbuffers/protobuf
Copyright: Copyright 2015, Google Inc.
License:   BSD-3-Clause

--------------------------------------------------------------------------------

Grpc.AspNetCore.Server

Id:        Grpc.AspNetCore.Server
Version:   2.70.0
Project:   https://github.com/grpc/grpc-dotnet
Copyright: Copyright 2019 The gRPC Authors
License:   Apache-2.0

--------------------------------------------------------------------------------

GrpcDotNetNamedPipes

Id:        GrpcDotNetNamedPipes
Version:   3.1.0
Project:   https://github.com/cyanfish/grpc-dotnet-namedpipes
Copyright: Copyright 2020 Google LLC
Apache-2.0

--------------------------------------------------------------------------------

JetBrains Annotations

Id:        JetBrains.Annotations
Version:   2025.1.0-eap1
Project:   https://www.jetbrains.com/help/resharper/Code_Analysis__Code_Annotations.html
Copyright: Copyright (c) 2016-2024 JetBrains s.r.o.
License:   MIT

--------------------------------------------------------------------------------

System.CommandLine

Id:        System.CommandLine
Version:   2.0.0-beta4.22272.1
Project:   https://github.com/dotnet/command-line-api
Copyright: © Microsoft Corporation. All rights reserved.
License:   MIT

