﻿using nadena.dev.ndmf;
#if MA_VRCSDK3_AVATARS
using UnityEditor.Animations;
using UnityEngine;
#endif

namespace nadena.dev.modular_avatar.core.editor
{
    /// <summary>
    ///     Reserve an animator layer for reactive object use. We do this here so that we can take advantage of MergeAnimator's
    ///     layer reference correction logic; this can go away once we have a more unified animation services API.
    /// </summary>
    [RunsOnPlatforms(WellKnownPlatforms.VRChatAvatar30)]
    internal class ReactiveObjectPrepass : Pass<ReactiveObjectPrepass>
    {
        internal const string TAG_PATH = "__MA/ShapeChanger/PrepassPlaceholder";
        internal const string LAYER_NAME = "MA Shape Changer Defaults";

        protected override void Execute(ndmf.BuildContext context)
        {
#if MA_VRCSDK3_AVATARS
            if (context.AvatarRootObject.GetComponentInChildren<ReactiveComponent>(true) != null)
            {
                var clip = new AnimationClip();
                clip.name = LAYER_NAME;

                var curve = new AnimationCurve();
                curve.AddKey(0, 0);
                clip.SetCurve(TAG_PATH, typeof(Transform), "localPosition.x", curve);

                // Merge using a null blend tree. This also ensures that we initialize the Merge Blend Tree system.
                var bt = new BlendTree();
                bt.name = LAYER_NAME;
                bt.blendType = BlendTreeType.Direct;
                bt.children = new[]
                {
                    new ChildMotion
                    {
                        motion = clip,
                        timeScale = 1,
                        cycleOffset = 0,
                        directBlendParameter = MergeBlendTreePass.ALWAYS_ONE
                    }
                };
                bt.useAutomaticThresholds = false;

                // This is a hack and a half - put in a dummy path so we can find the cloned clip later on...
                var obj = new GameObject("MA SC Defaults");
                obj.transform.SetParent(context.AvatarRootTransform);
                var mambt = obj.AddComponent<ModularAvatarMergeBlendTree>();
                mambt.Motion = bt;
                mambt.PathMode = MergeAnimatorPathMode.Absolute;
            }
#endif
        }
    }
}