﻿#region

using System.Runtime.CompilerServices;

#endregion

[assembly: InternalsVisibleTo("net.fushizen.xdress")]
[assembly: InternalsVisibleTo("net.fushizen.xdress.editor")]
[assembly: InternalsVisibleTo("nadena.dev.modular-avatar.harmony-patches")]
[assembly: InternalsVisibleTo("nadena.dev.modular-avatar.param-introspection")]
[assembly: InternalsVisibleTo("nadena.dev.modular-avatar.fit-preview")]
[assembly: InternalsVisibleTo("nadena.dev.modular-avatar.tests")]
[assembly: InternalsVisibleTo("nadena.dev.modular-avatar.tests.vrchat")]